=== Google Font Adder ===
Contributors: fpaul
Donate link: https://www.paypal.com/paypalme/csgobox
Tags: google font, tiny mce, text editor, font, google
Requires at least: 4.6